using System;
using System.Threading;
using System.Net;
using System.Web;
using System.Windows.Forms;
using System.IO;
using System.Collections;

namespace ProxyMonitor
{
	/// <summary>
	/// Description r�sum�e de ThreadApp.
	/// </summary>
	public class myThread
	{
		Form1 myform;   // formulaire pass� en parametre
		String[] taburls; //tableau contenant les urls � tester

        /**************************************************************************/
        /* Constructeur du  Thread                                                */
        /*                                                                        */
        /**************************************************************************/
        public myThread(Form1 form)
		{
			this.myform = form;
			int nburls = this.myform.urlList.Count;
			this.taburls = new String[nburls];
			int n = 0;
			foreach(String urls in this.myform.urlList)
			{
				taburls[n] = urls;
				n++;
			}
		}
        /**************************************************************************/
        /* Boucle du  Thread                                                      */
        /*                                                                        */
        /**************************************************************************/
		public void ThreadLoop()
		{
            while (Thread.CurrentThread.IsAlive)    // tant que le thread est vivant
            {
                Random rnd = new Random();  // on genere un nombre aleatoire
                int num = 0;                // afin de choisir une url � tester
                int cmpt = 0;
                foreach (String[] proxys in this.myform.proxyList)  // on parcours tous les proxys un par un
                {

                    String proxyAddress = proxys[1];
                    num = rnd.Next(this.taburls.Length);
                    String urlAddress = this.taburls[num];
                    try
                    {
                        // on configure le proxy
                        WebProxy myProxy = new WebProxy();
                        Uri myUriProxy = new Uri(proxyAddress);
                        myProxy.Address = myUriProxy;

                        // on genere la requeteWeb
                        WebRequest myWebRequest = WebRequest.Create(urlAddress);
                        myWebRequest.Proxy = myProxy;                           // on specifie le proxy � utiliser
                        WebResponse myWebResponse = myWebRequest.GetResponse(); // on se connecter a l'url via le proxy
                        myWebResponse.Close();                                  // on ferme la connexion
                        // si aucune exception est lev�e, on met a jour l'info du proxy � UP en invoquant la methode de la Frame
                        this.myform.Invoke(this.myform.ChangerProxyState, new object[] { cmpt, "UP" });
                    }
                    catch (WebException we)
                    {
                        // si une exception est lev�e, on met a jour l'info du proxy � DOWN en invoquant la methode de la Frame
                        this.myform.Invoke(this.myform.ChangerProxyState, new object[] { cmpt, "DOWN : " + we.Message });
                        try
                        {
                            // on log les erreur dans un fichier pour pouvoir les recuperer
                            FileStream fs = new FileStream("errorProxy.log", FileMode.OpenOrCreate, FileAccess.Write);
                            fs.Seek(0, System.IO.SeekOrigin.End);
                            StreamWriter monStreamWriter = new StreamWriter(fs);
                            // on ecrit les infos necessaire dans le fichier
                            monStreamWriter.WriteLine("DateTime : "+DateTime.Now + ";Proxy : " + proxyAddress + ";Url : " + urlAddress + ";Erreur : " + we.Message+"\n\n");
                            monStreamWriter.Close();
                            fs.Close(); //fermeture des Stream
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Erreur" + ex.Message);
                        }
                    }
                    cmpt++; // on passe au proxy suivant dans le tableau ListView
                    Thread.Sleep(1000);  // on endore le thread 1s avant de passer � l'autre proxy
                }
                Thread.Sleep(this.myform.refresh); // on endore le thread avant de recommencer les tests
            }
		}
	}
}
