using System;
using System.Threading;
using System.Net;
using System.Web;
using System.Windows.Forms;
using System.IO;
using System.Collections;

namespace ProxyMonitor
{
	/// <summary>
	/// Description r�sum�e de ThreadApp.
	/// </summary>
	public class myThread
	{
		Form1 myform;
		String[] taburls;

		public myThread(Form1 form)
		{
			this.myform = form;
			int nburls = this.myform.urlList.Count;
			this.taburls = new String[nburls];
			int n = 0;
			foreach(String urls in this.myform.urlList)
			{
				taburls[n] = urls;
				n++;
			}
		}

		public void ThreadLoop()
		{
			Random rnd = new Random();
			int num = 0;
			int cmpt = 0;
			foreach(String[] proxys in this.myform.proxyList)
			{
				try
				{
					String proxyAddress = proxys[1];
					num = rnd.Next(this.taburls.Length);
					String urlAddress = this.taburls[num];
					
					WebProxy myProxy=new WebProxy();
					Uri myUriProxy = new Uri(proxyAddress);
					myProxy.Address = myUriProxy;
					
					WebRequest myWebRequest=WebRequest.Create(urlAddress);
					myWebRequest.Proxy = myProxy;
					WebResponse myWebResponse=myWebRequest.GetResponse();
					
				}
				catch (WebException e)
				{
					MessageBox.Show("erreur"+e.Message);
				}
				//test la reponse du proxy
				//if(){
				this.myform.Invoke(this.myform.ChangerProxyState,new object [] {cmpt,"up"});
				cmpt++;
				//}
				//myWebResponse.
				Thread.Sleep(300);
			}
			Thread.Sleep(10000);

		}
	}
}
