using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace ProxyMonitor
{
	/// <summary>
	/// Description r�sum�e de Form2.
	/// </summary>
	public class Form2 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.CheckedListBox proxyListBox;
		private System.Windows.Forms.Button ajouterProxyButton;
		private System.Windows.Forms.Button modifProxyButton;
		private System.Windows.Forms.Button supprProxyButton;
		private System.Windows.Forms.Label labelGestProxy;
		/// <summary>
		/// Variable n�cessaire au concepteur.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form2()
		{
			//
			// Requis pour la prise en charge du Concepteur Windows Forms
			//
			InitializeComponent();
			
			
		}

		/// <summary>
		/// Nettoyage des ressources utilis�es.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Code g�n�r� par le Concepteur Windows Form
		/// <summary>
		/// M�thode requise pour la prise en charge du concepteur - ne modifiez pas
		/// le contenu de cette m�thode avec l'�diteur de code.
		/// </summary>
		private void InitializeComponent()
		{
			this.proxyListBox = new System.Windows.Forms.CheckedListBox();
			this.ajouterProxyButton = new System.Windows.Forms.Button();
			this.modifProxyButton = new System.Windows.Forms.Button();
			this.supprProxyButton = new System.Windows.Forms.Button();
			this.labelGestProxy = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// proxyListBox
			// 
			this.proxyListBox.CheckOnClick = true;
			this.proxyListBox.Location = new System.Drawing.Point(24, 48);
			this.proxyListBox.MultiColumn = true;
			this.proxyListBox.Name = "proxyListBox";
			this.proxyListBox.Size = new System.Drawing.Size(312, 94);
			this.proxyListBox.Sorted = true;
			this.proxyListBox.TabIndex = 0;
			this.proxyListBox.ThreeDCheckBoxes = true;
			this.proxyListBox.SelectedIndexChanged += new System.EventHandler(this.proxyListBox_SelectedIndexChanged);
			// 
			// ajouterProxyButton
			// 
			this.ajouterProxyButton.Location = new System.Drawing.Point(24, 152);
			this.ajouterProxyButton.Name = "ajouterProxyButton";
			this.ajouterProxyButton.Size = new System.Drawing.Size(96, 24);
			this.ajouterProxyButton.TabIndex = 1;
			this.ajouterProxyButton.Text = "Ajouter";
			this.ajouterProxyButton.Click += new System.EventHandler(this.button1_Click);
			// 
			// modifProxyButton
			// 
			this.modifProxyButton.Location = new System.Drawing.Point(128, 152);
			this.modifProxyButton.Name = "modifProxyButton";
			this.modifProxyButton.Size = new System.Drawing.Size(104, 24);
			this.modifProxyButton.TabIndex = 2;
			this.modifProxyButton.Text = "Modifier";
			// 
			// supprProxyButton
			// 
			this.supprProxyButton.Location = new System.Drawing.Point(240, 152);
			this.supprProxyButton.Name = "supprProxyButton";
			this.supprProxyButton.Size = new System.Drawing.Size(96, 24);
			this.supprProxyButton.TabIndex = 3;
			this.supprProxyButton.Text = "Supprimer";
			// 
			// labelGestProxy
			// 
			this.labelGestProxy.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelGestProxy.Location = new System.Drawing.Point(40, 8);
			this.labelGestProxy.Name = "labelGestProxy";
			this.labelGestProxy.Size = new System.Drawing.Size(280, 32);
			this.labelGestProxy.TabIndex = 4;
			this.labelGestProxy.Text = "Gestion des Proxys";
			this.labelGestProxy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// Form2
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(352, 189);
			this.Controls.Add(this.labelGestProxy);
			this.Controls.Add(this.supprProxyButton);
			this.Controls.Add(this.modifProxyButton);
			this.Controls.Add(this.ajouterProxyButton);
			this.Controls.Add(this.proxyListBox);
			this.Name = "Form2";
			this.Text = "Gestion des proxys";
			this.ResumeLayout(false);

		}
		#endregion

		private void button1_Click(object sender, System.EventArgs e)
		{
		
		}

		private void proxyListBox_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}
	}
}
