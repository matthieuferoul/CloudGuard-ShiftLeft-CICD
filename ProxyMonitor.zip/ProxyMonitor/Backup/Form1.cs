using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading;
using System.IO;

namespace ProxyMonitor
{
	/// <summary>
	/// Description r�sum�e de Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button proxyButton;
		private System.Windows.Forms.Button urlButton;
		private System.Windows.Forms.Button optButton;
		private System.Windows.Forms.Button quitButton;
		private System.Windows.Forms.ColumnHeader nomColumn;
		private System.Windows.Forms.ColumnHeader adresseColumn;
		private System.Windows.Forms.ColumnHeader etatColumn;
		private System.Windows.Forms.ListView listView1;
		public ListView listView
		{
			get
			{
				return listView;
			}
			set
			{
				listView = value;
			}
		}
		
		/// <summary>
		/// Variable n�cessaire au concepteur.
		/// </summary>
		private System.ComponentModel.Container components = null;
		
		private ArrayList myProxyList;
		public ArrayList proxyList
		{
			get
			{
				return myProxyList;
			}
			set
			{
				myProxyList = value;
			}
		}

		private ArrayList myUrlList;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
	
		public ArrayList urlList
		{
			get
			{
				return myUrlList;
			}
			set
			{
				myUrlList = value;
			}
		}
		public delegate void ChangerProxy(int prox,String state);
		public ChangerProxy ChangerProxyState;
		public void ChangerProxyStateMethod(int prox,String state)
		{
			this.listView1.Items[prox].SubItems[2].Text = state;
		}

		public Form1()
		{
			InitializeComponent();
			
			String s = null;
			// lecture du fichier contenant les proxys
			String[] tab = new String[2];
			// lecture du fichier contenant les proxys

			this.myProxyList = new ArrayList();
			String fichProxy = "E:\\Documents and Settings\\rOOtSh4rK\\Mes documents\\Visual Studio Projects\\proxymon\\ProxyMonitor\\proxy.lst";
			StreamReader sr1 = new StreamReader(new FileStream(fichProxy,FileMode.Open));
			do
			{
				s = sr1.ReadLine();
				if((s != null) && (s[0] != '#'))
				{
					tab = s.Split(';');
					myProxyList.Add(tab);
				}
			} while((s != null) && (s[0] != '#'));
			// lecture du fichier contenant les urls

			this.myUrlList = new ArrayList();
			String fichUrl = "E:\\Documents and Settings\\rOOtSh4rK\\Mes documents\\Visual Studio Projects\\proxymon\\ProxyMonitor\\url.lst";
			StreamReader sr2 = new StreamReader(new FileStream(fichUrl,FileMode.Open));
			do
			{
				s = sr2.ReadLine();
				if((s != null) && (s[0] != '#'))
				{
					myUrlList.Add(s); 
				}
			} while((s != null) && (s[0] != '#'));
			
			
			
			// remplir le tableau avec les infos contenus dans
			// les fichiers
			int nbProxys = myProxyList.Count;
			int nbUrls = myUrlList.Count;
			
			int i = 0;
			ListViewItem[] tabProxy = new ListViewItem[nbProxys];
			
			foreach(String[] proxys in myProxyList)
			{
				ListViewItem it = new ListViewItem("test"+i,0);
				it.Text = proxys[0];
				it.SubItems.Add(proxys[1]);
				it.SubItems.Add("none");
				tabProxy[i] = it;
				i++;
			}
			listView1.Items.AddRange(tabProxy);

			this.ChangerProxyState = new ChangerProxy(this.ChangerProxyStateMethod);
			// Demarrer le thread de test des proxy
			myThread thread = new myThread(this);
			Thread t = new Thread(new ThreadStart(thread.ThreadLoop));
			t.Start();
		}

		/// <summary>
		/// Nettoyage des ressources utilis�es.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Code g�n�r� par le Concepteur Windows Form
		/// <summary>
		/// M�thode requise pour la prise en charge du concepteur - ne modifiez pas
		/// le contenu de cette m�thode avec l'�diteur de code.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.proxyButton = new System.Windows.Forms.Button();
			this.urlButton = new System.Windows.Forms.Button();
			this.listView1 = new System.Windows.Forms.ListView();
			this.nomColumn = new System.Windows.Forms.ColumnHeader();
			this.adresseColumn = new System.Windows.Forms.ColumnHeader();
			this.etatColumn = new System.Windows.Forms.ColumnHeader();
			this.label1 = new System.Windows.Forms.Label();
			this.optButton = new System.Windows.Forms.Button();
			this.quitButton = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.SuspendLayout();
			// 
			// proxyButton
			// 
			this.proxyButton.AccessibleDescription = resources.GetString("proxyButton.AccessibleDescription");
			this.proxyButton.AccessibleName = resources.GetString("proxyButton.AccessibleName");
			this.proxyButton.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("proxyButton.Anchor")));
			this.proxyButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("proxyButton.BackgroundImage")));
			this.proxyButton.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("proxyButton.Dock")));
			this.proxyButton.Enabled = ((bool)(resources.GetObject("proxyButton.Enabled")));
			this.proxyButton.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("proxyButton.FlatStyle")));
			this.proxyButton.Font = ((System.Drawing.Font)(resources.GetObject("proxyButton.Font")));
			this.proxyButton.Image = ((System.Drawing.Image)(resources.GetObject("proxyButton.Image")));
			this.proxyButton.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("proxyButton.ImageAlign")));
			this.proxyButton.ImageIndex = ((int)(resources.GetObject("proxyButton.ImageIndex")));
			this.proxyButton.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("proxyButton.ImeMode")));
			this.proxyButton.Location = ((System.Drawing.Point)(resources.GetObject("proxyButton.Location")));
			this.proxyButton.Name = "proxyButton";
			this.proxyButton.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("proxyButton.RightToLeft")));
			this.proxyButton.Size = ((System.Drawing.Size)(resources.GetObject("proxyButton.Size")));
			this.proxyButton.TabIndex = ((int)(resources.GetObject("proxyButton.TabIndex")));
			this.proxyButton.Text = resources.GetString("proxyButton.Text");
			this.proxyButton.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("proxyButton.TextAlign")));
			this.proxyButton.Visible = ((bool)(resources.GetObject("proxyButton.Visible")));
			this.proxyButton.Click += new System.EventHandler(this.button1_Click);
			// 
			// urlButton
			// 
			this.urlButton.AccessibleDescription = resources.GetString("urlButton.AccessibleDescription");
			this.urlButton.AccessibleName = resources.GetString("urlButton.AccessibleName");
			this.urlButton.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("urlButton.Anchor")));
			this.urlButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("urlButton.BackgroundImage")));
			this.urlButton.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("urlButton.Dock")));
			this.urlButton.Enabled = ((bool)(resources.GetObject("urlButton.Enabled")));
			this.urlButton.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("urlButton.FlatStyle")));
			this.urlButton.Font = ((System.Drawing.Font)(resources.GetObject("urlButton.Font")));
			this.urlButton.Image = ((System.Drawing.Image)(resources.GetObject("urlButton.Image")));
			this.urlButton.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("urlButton.ImageAlign")));
			this.urlButton.ImageIndex = ((int)(resources.GetObject("urlButton.ImageIndex")));
			this.urlButton.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("urlButton.ImeMode")));
			this.urlButton.Location = ((System.Drawing.Point)(resources.GetObject("urlButton.Location")));
			this.urlButton.Name = "urlButton";
			this.urlButton.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("urlButton.RightToLeft")));
			this.urlButton.Size = ((System.Drawing.Size)(resources.GetObject("urlButton.Size")));
			this.urlButton.TabIndex = ((int)(resources.GetObject("urlButton.TabIndex")));
			this.urlButton.Text = resources.GetString("urlButton.Text");
			this.urlButton.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("urlButton.TextAlign")));
			this.urlButton.Visible = ((bool)(resources.GetObject("urlButton.Visible")));
			this.urlButton.Click += new System.EventHandler(this.button2_Click);
			// 
			// listView1
			// 
			this.listView1.AccessibleDescription = resources.GetString("listView1.AccessibleDescription");
			this.listView1.AccessibleName = resources.GetString("listView1.AccessibleName");
			this.listView1.Alignment = ((System.Windows.Forms.ListViewAlignment)(resources.GetObject("listView1.Alignment")));
			this.listView1.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("listView1.Anchor")));
			this.listView1.BackColor = System.Drawing.SystemColors.Info;
			this.listView1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("listView1.BackgroundImage")));
			this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						this.nomColumn,
																						this.adresseColumn,
																						this.etatColumn});
			this.listView1.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("listView1.Dock")));
			this.listView1.Enabled = ((bool)(resources.GetObject("listView1.Enabled")));
			this.listView1.Font = ((System.Drawing.Font)(resources.GetObject("listView1.Font")));
			this.listView1.GridLines = true;
			this.listView1.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("listView1.ImeMode")));
			this.listView1.LabelWrap = ((bool)(resources.GetObject("listView1.LabelWrap")));
			this.listView1.Location = ((System.Drawing.Point)(resources.GetObject("listView1.Location")));
			this.listView1.Name = "listView1";
			this.listView1.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("listView1.RightToLeft")));
			this.listView1.Size = ((System.Drawing.Size)(resources.GetObject("listView1.Size")));
			this.listView1.Sorting = System.Windows.Forms.SortOrder.Ascending;
			this.listView1.TabIndex = ((int)(resources.GetObject("listView1.TabIndex")));
			this.listView1.TabStop = false;
			this.listView1.Text = resources.GetString("listView1.Text");
			this.listView1.View = System.Windows.Forms.View.Details;
			this.listView1.Visible = ((bool)(resources.GetObject("listView1.Visible")));
			// 
			// nomColumn
			// 
			this.nomColumn.Text = resources.GetString("nomColumn.Text");
			this.nomColumn.TextAlign = ((System.Windows.Forms.HorizontalAlignment)(resources.GetObject("nomColumn.TextAlign")));
			this.nomColumn.Width = ((int)(resources.GetObject("nomColumn.Width")));
			// 
			// adresseColumn
			// 
			this.adresseColumn.Text = resources.GetString("adresseColumn.Text");
			this.adresseColumn.TextAlign = ((System.Windows.Forms.HorizontalAlignment)(resources.GetObject("adresseColumn.TextAlign")));
			this.adresseColumn.Width = ((int)(resources.GetObject("adresseColumn.Width")));
			// 
			// etatColumn
			// 
			this.etatColumn.Text = resources.GetString("etatColumn.Text");
			this.etatColumn.TextAlign = ((System.Windows.Forms.HorizontalAlignment)(resources.GetObject("etatColumn.TextAlign")));
			this.etatColumn.Width = ((int)(resources.GetObject("etatColumn.Width")));
			// 
			// label1
			// 
			this.label1.AccessibleDescription = resources.GetString("label1.AccessibleDescription");
			this.label1.AccessibleName = resources.GetString("label1.AccessibleName");
			this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("label1.Anchor")));
			this.label1.AutoSize = ((bool)(resources.GetObject("label1.AutoSize")));
			this.label1.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("label1.Dock")));
			this.label1.Enabled = ((bool)(resources.GetObject("label1.Enabled")));
			this.label1.Font = ((System.Drawing.Font)(resources.GetObject("label1.Font")));
			this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
			this.label1.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("label1.ImageAlign")));
			this.label1.ImageIndex = ((int)(resources.GetObject("label1.ImageIndex")));
			this.label1.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("label1.ImeMode")));
			this.label1.Location = ((System.Drawing.Point)(resources.GetObject("label1.Location")));
			this.label1.Name = "label1";
			this.label1.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("label1.RightToLeft")));
			this.label1.Size = ((System.Drawing.Size)(resources.GetObject("label1.Size")));
			this.label1.TabIndex = ((int)(resources.GetObject("label1.TabIndex")));
			this.label1.Text = resources.GetString("label1.Text");
			this.label1.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("label1.TextAlign")));
			this.label1.Visible = ((bool)(resources.GetObject("label1.Visible")));
			// 
			// optButton
			// 
			this.optButton.AccessibleDescription = resources.GetString("optButton.AccessibleDescription");
			this.optButton.AccessibleName = resources.GetString("optButton.AccessibleName");
			this.optButton.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("optButton.Anchor")));
			this.optButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("optButton.BackgroundImage")));
			this.optButton.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("optButton.Dock")));
			this.optButton.Enabled = ((bool)(resources.GetObject("optButton.Enabled")));
			this.optButton.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("optButton.FlatStyle")));
			this.optButton.Font = ((System.Drawing.Font)(resources.GetObject("optButton.Font")));
			this.optButton.Image = ((System.Drawing.Image)(resources.GetObject("optButton.Image")));
			this.optButton.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("optButton.ImageAlign")));
			this.optButton.ImageIndex = ((int)(resources.GetObject("optButton.ImageIndex")));
			this.optButton.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("optButton.ImeMode")));
			this.optButton.Location = ((System.Drawing.Point)(resources.GetObject("optButton.Location")));
			this.optButton.Name = "optButton";
			this.optButton.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("optButton.RightToLeft")));
			this.optButton.Size = ((System.Drawing.Size)(resources.GetObject("optButton.Size")));
			this.optButton.TabIndex = ((int)(resources.GetObject("optButton.TabIndex")));
			this.optButton.Text = resources.GetString("optButton.Text");
			this.optButton.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("optButton.TextAlign")));
			this.optButton.Visible = ((bool)(resources.GetObject("optButton.Visible")));
			// 
			// quitButton
			// 
			this.quitButton.AccessibleDescription = resources.GetString("quitButton.AccessibleDescription");
			this.quitButton.AccessibleName = resources.GetString("quitButton.AccessibleName");
			this.quitButton.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("quitButton.Anchor")));
			this.quitButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("quitButton.BackgroundImage")));
			this.quitButton.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("quitButton.Dock")));
			this.quitButton.Enabled = ((bool)(resources.GetObject("quitButton.Enabled")));
			this.quitButton.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("quitButton.FlatStyle")));
			this.quitButton.Font = ((System.Drawing.Font)(resources.GetObject("quitButton.Font")));
			this.quitButton.Image = ((System.Drawing.Image)(resources.GetObject("quitButton.Image")));
			this.quitButton.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("quitButton.ImageAlign")));
			this.quitButton.ImageIndex = ((int)(resources.GetObject("quitButton.ImageIndex")));
			this.quitButton.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("quitButton.ImeMode")));
			this.quitButton.Location = ((System.Drawing.Point)(resources.GetObject("quitButton.Location")));
			this.quitButton.Name = "quitButton";
			this.quitButton.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("quitButton.RightToLeft")));
			this.quitButton.Size = ((System.Drawing.Size)(resources.GetObject("quitButton.Size")));
			this.quitButton.TabIndex = ((int)(resources.GetObject("quitButton.TabIndex")));
			this.quitButton.Text = resources.GetString("quitButton.Text");
			this.quitButton.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("quitButton.TextAlign")));
			this.quitButton.Visible = ((bool)(resources.GetObject("quitButton.Visible")));
			this.quitButton.Click += new System.EventHandler(this.button1_Click_1);
			// 
			// groupBox1
			// 
			this.groupBox1.AccessibleDescription = resources.GetString("groupBox1.AccessibleDescription");
			this.groupBox1.AccessibleName = resources.GetString("groupBox1.AccessibleName");
			this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("groupBox1.Anchor")));
			this.groupBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBox1.BackgroundImage")));
			this.groupBox1.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("groupBox1.Dock")));
			this.groupBox1.Enabled = ((bool)(resources.GetObject("groupBox1.Enabled")));
			this.groupBox1.Font = ((System.Drawing.Font)(resources.GetObject("groupBox1.Font")));
			this.groupBox1.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("groupBox1.ImeMode")));
			this.groupBox1.Location = ((System.Drawing.Point)(resources.GetObject("groupBox1.Location")));
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("groupBox1.RightToLeft")));
			this.groupBox1.Size = ((System.Drawing.Size)(resources.GetObject("groupBox1.Size")));
			this.groupBox1.TabIndex = ((int)(resources.GetObject("groupBox1.TabIndex")));
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = resources.GetString("groupBox1.Text");
			this.groupBox1.Visible = ((bool)(resources.GetObject("groupBox1.Visible")));
			// 
			// groupBox2
			// 
			this.groupBox2.AccessibleDescription = resources.GetString("groupBox2.AccessibleDescription");
			this.groupBox2.AccessibleName = resources.GetString("groupBox2.AccessibleName");
			this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("groupBox2.Anchor")));
			this.groupBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBox2.BackgroundImage")));
			this.groupBox2.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("groupBox2.Dock")));
			this.groupBox2.Enabled = ((bool)(resources.GetObject("groupBox2.Enabled")));
			this.groupBox2.Font = ((System.Drawing.Font)(resources.GetObject("groupBox2.Font")));
			this.groupBox2.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("groupBox2.ImeMode")));
			this.groupBox2.Location = ((System.Drawing.Point)(resources.GetObject("groupBox2.Location")));
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("groupBox2.RightToLeft")));
			this.groupBox2.Size = ((System.Drawing.Size)(resources.GetObject("groupBox2.Size")));
			this.groupBox2.TabIndex = ((int)(resources.GetObject("groupBox2.TabIndex")));
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = resources.GetString("groupBox2.Text");
			this.groupBox2.Visible = ((bool)(resources.GetObject("groupBox2.Visible")));
			// 
			// Form1
			// 
			this.AccessibleDescription = resources.GetString("$this.AccessibleDescription");
			this.AccessibleName = resources.GetString("$this.AccessibleName");
			this.AutoScaleBaseSize = ((System.Drawing.Size)(resources.GetObject("$this.AutoScaleBaseSize")));
			this.AutoScroll = ((bool)(resources.GetObject("$this.AutoScroll")));
			this.AutoScrollMargin = ((System.Drawing.Size)(resources.GetObject("$this.AutoScrollMargin")));
			this.AutoScrollMinSize = ((System.Drawing.Size)(resources.GetObject("$this.AutoScrollMinSize")));
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.ClientSize = ((System.Drawing.Size)(resources.GetObject("$this.ClientSize")));
			this.Controls.Add(this.quitButton);
			this.Controls.Add(this.optButton);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.listView1);
			this.Controls.Add(this.urlButton);
			this.Controls.Add(this.proxyButton);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.groupBox2);
			this.Enabled = ((bool)(resources.GetObject("$this.Enabled")));
			this.Font = ((System.Drawing.Font)(resources.GetObject("$this.Font")));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("$this.ImeMode")));
			this.Location = ((System.Drawing.Point)(resources.GetObject("$this.Location")));
			this.MaximumSize = ((System.Drawing.Size)(resources.GetObject("$this.MaximumSize")));
			this.MinimumSize = ((System.Drawing.Size)(resources.GetObject("$this.MinimumSize")));
			this.Name = "Form1";
			this.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("$this.RightToLeft")));
			this.StartPosition = ((System.Windows.Forms.FormStartPosition)(resources.GetObject("$this.StartPosition")));
			this.Text = resources.GetString("$this.Text");
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Point d'entr�e principal de l'application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			Form2 myGestProxy = new Form2();
			myGestProxy.ShowDialog();
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			Form2 myGestUrl = new Form2();
			myGestUrl.ShowDialog();
		}

		private void button1_Click_1(object sender, System.EventArgs e)
		{
			this.Dispose();
		}

	}
}
