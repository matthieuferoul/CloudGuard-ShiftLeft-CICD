using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading;
using System.IO;

namespace ProxyMonitor
{
	/// <summary>
	/// Description r�sum�e de Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
    {
        /**************************************************************************/
        /* ImageList permettant d'afficher les images d'Etat                      */
        /**************************************************************************/
        private System.Windows.Forms.ImageList imageList1;
        // private System.ComponentModel.IContainer components;
        private IContainer components;
        /*************************************/
        /* Getter et Setter pour la listView */
        /*************************************/
		public ListView listView
		{
			get{return listView;}
			set{listView = value;}
        }
        /*******************************************/
        /* Getter et Setter pour la liste de proxy */
        /*******************************************/
		private ArrayList myProxyList;
		public ArrayList proxyList
		{
			get{return myProxyList;}
			set{myProxyList = value;}
		}
        /**************************************************************************/
        /* Variables de la Frame                                                 */
        /**************************************************************************/
        private ArrayList myUrlList;
        private ListView listView1;
        private ColumnHeader nomColumn;
        private ColumnHeader adresseColumn;
        private ColumnHeader etatColumn;
        private Label label1;
        private Button button1;
        private GroupBox groupBox1;
        private TextBox textBox1;
        private Label label2;
        private Button button2;
        /**************************************************************************/
        /* Getter et Setter pour la liste d'urls                                  */
        /**************************************************************************/
		public ArrayList urlList
		{
			get{return myUrlList;}
			set{myUrlList = value;}
		}
        /**************************************************************************/
        /* Methode Delegu� ChangerProxy                                           */
        /* Cette methode permet de modifier la mainFrame a partir du thread       */
        /**************************************************************************/
		public delegate void ChangerProxy(int prox,String state);
		public ChangerProxy ChangerProxyState;
		public void ChangerProxyStateMethod(int prox,String state)
		{
            if (state.CompareTo("UP") == 0)
            {
                this.listView1.Items[prox].ImageIndex = 1;
            }
            else
            {
                this.listView1.Items[prox].ImageIndex = 2;
            }
            this.listView1.Items[prox].SubItems[2].Text = state;
		}
        /**************************************************************************/
        /* Variables supplementaires                                              */
        /**************************************************************************/
        private Thread t;
        public Int32 refresh;

		public Form1()
		{
			InitializeComponent();
            /**************************************************************************/
            /* Met � jour la variable refresh : par default 10s                       */
            /**************************************************************************/
            this.refresh = 10000;
            Int32 tempRef = this.refresh / 1000;
            this.label2.Text = tempRef.ToString()+"s";
            /**************************************************************************/
            /* Recuperation des infos dans les fichiers                               */
            /*      -liste des proxys                                                 */
            /*      -liste des ulrs de test                                           */
            /**************************************************************************/
			String s = null;
			// Fichier proxys
            String[] tab = new String[2];   // tableau de 2 : nomproxy et adresseproxy
            try
            {
                this.myProxyList = new ArrayList();
                String fichProxy = "proxy.lst";
                try
                {
                    StreamReader sr1 = new StreamReader(new FileStream(fichProxy, FileMode.Open));
                    do
                    {
                        s = sr1.ReadLine();
                        if ((s != null) && (s[0] != '#'))
                        {
                            tab = s.Split(';'); // recupere les infos du fichiers et les decoupents
                            myProxyList.Add(tab); // place les infos proxys dans une ArrayList
                        }
                    } while (s != null);
                    sr1.Close();
                    // Fichier urls
                    this.myUrlList = new ArrayList();
                    String fichUrl = "url.lst";
                    StreamReader sr2 = new StreamReader(new FileStream(fichUrl, FileMode.Open));
                    do
                    {
                        s = sr2.ReadLine();
                        if ((s != null) && (s[0] != '#'))
                        {
                            myUrlList.Add(s);
                        }
                    } while (s != null);
                    sr2.Close();
                }
                catch (FileNotFoundException fnfe)
                {
                    MessageBox.Show("Erreur : " + fnfe.Message);
                    this.Dispose();
                }
                catch (IOException ioe)
                {
                    MessageBox.Show("Erreur : " + ioe.Message);
                    this.Dispose();
                }
                /**************************************************************************/
                /* Ajout des donn�es dans la ViewList de la Frame                         */
                /*                                                                        */
                /**************************************************************************/
                int nbProxys = myProxyList.Count;
                int nbUrls = myUrlList.Count;

                int i = 0;
                ListViewItem[] tabProxy = new ListViewItem[nbProxys];

                foreach (String[] proxys in myProxyList)
                {
                    ListViewItem it = new ListViewItem("test" + i, 0);
                    it.Text = proxys[0];
                    it.SubItems.Add(proxys[1]);
                    it.SubItems.Add("none");
                    tabProxy[i] = it;
                    i++;
                }
                listView1.Items.AddRange(tabProxy);
            }
            catch (IOException ioe)
            {
                MessageBox.Show("Erreur : " + ioe.Message);
            }
            /**************************************************************************/
            /* Lancement du Thread permettant le test des proxys                      */
            /*                                                                        */
            /**************************************************************************/
			this.ChangerProxyState = new ChangerProxy(this.ChangerProxyStateMethod);
			// Demarrer le thread de test des proxy
			myThread thread = new myThread(this);
			this.t = new Thread(new ThreadStart(thread.ThreadLoop));
			t.Start();
            /**************************************************************************/
            System.Windows.Forms.NotifyIcon NotifyIcon1 = new System.Windows.Forms.NotifyIcon();
            NotifyIcon1.Icon = this.Icon;
            NotifyIcon1.Text = "ProxyMon";
            NotifyIcon1.Visible = true;
		}

		/// <summary>
		/// Nettoyage des ressources utilis�es.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
            if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Code g�n�r� par le Concepteur Windows Form
		/// <summary>
		/// M�thode requise pour la prise en charge du concepteur - ne modifiez pas
		/// le contenu de cette m�thode avec l'�diteur de code.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.listView1 = new System.Windows.Forms.ListView();
            this.nomColumn = new System.Windows.Forms.ColumnHeader();
            this.adresseColumn = new System.Windows.Forms.ColumnHeader();
            this.etatColumn = new System.Windows.Forms.ColumnHeader(resources.GetString("listView1.Columns"));
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.imageList1.Images.SetKeyName(0, "greydot.gif");
            this.imageList1.Images.SetKeyName(1, "greendot.gif");
            this.imageList1.Images.SetKeyName(2, "orangedot.gif");
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.SystemColors.Info;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.nomColumn,
            this.adresseColumn,
            this.etatColumn});
            resources.ApplyResources(this.listView1, "listView1");
            this.listView1.GridLines = true;
            this.listView1.MultiSelect = false;
            this.listView1.Name = "listView1";
            this.listView1.SmallImageList = this.imageList1;
            this.listView1.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.listView1.TabStop = false;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // nomColumn
            // 
            resources.ApplyResources(this.nomColumn, "nomColumn");
            // 
            // adresseColumn
            // 
            resources.ApplyResources(this.adresseColumn, "adresseColumn");
            // 
            // etatColumn
            // 
            resources.ApplyResources(this.etatColumn, "etatColumn");
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.button2);
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            this.groupBox1.Enabled = true;
            // 
            // label2
            // 
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // textBox1
            // 
            resources.ApplyResources(this.textBox1, "textBox1");
            this.textBox1.Name = "textBox1";
            // 
            // button2
            // 
            resources.ApplyResources(this.button2, "button2");
            this.button2.Name = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.HelpButton = true;
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.Enabled = true;

		}
		#endregion

		/// <summary>
		/// Point d'entr�e principal de l'application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
        /**************************************************************************/
        /* Methode effectu� lors du click du bouton "Quitter"                     */
        /*                                                                        */
        /**************************************************************************/
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // on tue le thread avant de fermer
                t.Abort();
            }
            catch (ThreadAbortException tae)
            {
                MessageBox.Show("Erreur : " + tae.Message);
            }
            this.Dispose(); // fermeture de la fenetre principale
        }
        /**************************************************************************/
        /* Methode effectu� lors du click du bouton "Changer"                     */
        /*                                                                        */
        /**************************************************************************/
        private void button2_Click(object sender, EventArgs e)
        {
            // on modifie la valeur dans la fenetre
            
            try
            {
                if (this.textBox1.Text.CompareTo("") != 0) // on verifie que la fenetre n'est pas vide
                {
                    // on modifie la valeur dans la donn�es membre refresh
                    this.refresh = Int32.Parse(this.textBox1.Text)*1000;
                    this.label2.Text = this.textBox1.Text + "s";
                }
            }
            catch (FormatException fe)
            {
                MessageBox.Show("Erreur : " + fe.Message);
            }
        }

	}
}
